function out = ode_comp_fun(A,x_0,t)
  
n = size(A,1);
[V,D] = eig(A);

j=1;

while j <= n
   if abs(imag(D(j,j))) > 0.000001
      a=real(D(j,j));
      b=imag(D(j,j));
      B(j:j+1,j:j+1)=exp(a*t)*[cos(b*t) -sin(b*t);sin(b*t) cos(b*t)];
      P(:,j)=imag(V(:,j));
      P(:,j+1)=real(V(:,j+1));
      j = j+2;
    else B(j,j)=exp(D(j,j)*t);
       P(:,j)=V(:,j);
       j = j+1;
    end
end

out = (P*B/P)*x_0;