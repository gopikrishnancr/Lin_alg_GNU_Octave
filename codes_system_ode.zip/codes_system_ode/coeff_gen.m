function output = coeff_gen(V)
  
  n = length(V) - 1;
  eye_coef = eye(n-1);
  Va_coef = -V(1:n,1)/V(n+1,1);
  zero_coef = zeros(n-1,1);
  output = [[zero_coef eye_coef]; Va_coef'];
  
endfunction
