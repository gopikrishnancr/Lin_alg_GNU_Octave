function output = ode_real_fun(A,x_0,t)

% This is a function file. Do not run it as we do for script files. You need to
% call it using the command ode_Real_fun(A,x_0,t). 
%
% A   - coefficient matrix
% x_0 - initial data
% t   - point of evaluation
%
%   eg.    x_0 = [0;1]
%          sol = ode_real_fun(Ma,x_0,0.2);
%

n = size(A,1);     % number of rows of A = dimension of A
[P, D] = eig(A);   % eigenvalue diagonal matrix and eigenvector matrix
output = (P*diag(exp(diag(D)*t))/P)*x_0;


endfunction
