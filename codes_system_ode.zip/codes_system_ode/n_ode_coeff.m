% Coefficients of the nth order ordinary differential equations. 

Va = [40; 4; 1];
Vb = [0; 3; -1; 0; -1];