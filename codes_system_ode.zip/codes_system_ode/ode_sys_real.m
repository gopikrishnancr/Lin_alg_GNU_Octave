% This code is to compute symbolic solutions to system of ordinary differential 
% equations with real eigenvalues and eigenvectors. Change the coefficient matrix
% 'Ma' in line 9. x_0 is the intial data. 

clear all;
clc
coeff_matrix;

n = size(Ma,1);     % number of rows of A = dimension of A
[P, D] = eig(Ma);   % eigenvalue diagonal matrix and eigenvector matrix

x_0 = zeros(n,1);
x_0(1) = 1;

pkg load symbolic;
syms t;

x_sol(t) = (P*diag(exp(diag(D)*t))/P)*x_0;

% A word of caution: The symbolic code gives solutions in the symbolic form. 
% However, the floating points are converted to rational approximations. So, as
% a word of caution, its better to use the function form (see ode_real_fun.m) 
% without invoking symbolic pacakge. But, for illutrative purposes and small 
% systems with integer coefficients, inter eigenvalue and eigenvector, 'symbolic' 
% is a nice and beautiful package. 