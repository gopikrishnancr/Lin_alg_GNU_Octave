coeff_matrix
clc

% The eigenvalues diagonal matrices (D) and eigenvetor matrices (P)

fprintf('%30s \n','--------------------------------------------------')
[Pa, Da] = eig(Ma)
fprintf('%30s \n','--------------------------------------------------')
[Pb, Db] = eig(Mb)
fprintf('%30s \n','--------------------------------------------------')
[Pc, Dc] = eig(Mc)
fprintf('%30s \n','--------------------------------------------------')
[Pd, Dd] = eig(Md)
fprintf('%30s \n','--------------------------------------------------')
[Pe, De] = eig(Me)
fprintf('%30s \n','--------------------------------------------------')


% fprintf is the command to display the separating lines, ------.