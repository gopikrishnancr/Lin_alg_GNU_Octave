clear all;
clc;

% This is a plot function to show the solutions of the system of ordinary differential
% equations. 

coeff_matrix;

tsol = linspace(0,5,100);
xdata = zeros(2,100);

for i = 1:length(tsol)
  xdata(:,i) = ode_comp_fun(Mb,[1;0],tsol(i));
  
end

plot(tsol,xdata(1,:),'-r');
hold on;
plot(tsol,xdata(2,:),'-b');
legend('x_1','x_2');