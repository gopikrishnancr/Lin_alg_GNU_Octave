% Solution of ODE Q.(5a)
clear all;
clc;

n_ode_coeff;

% Chanage Va to change the coefficient vector.
coeff_m = coeff_gen(Va);

n = size(coeff_m , 1);
[V,D] = eig(coeff_m);
x_0 = [1; 0];

syms t;

j=1;

while j <= n
   if abs(imag(D(j,j))) > 0.000001
      a = real(D(j,j));
      b = imag(D(j,j));
      B(j:j+1,j:j+1) = exp(a*t)*[cos(b*t) -sin(b*t);sin(b*t) cos(b*t)];
      P(:,j) = imag(V(:,j));
      P(:,j+1) = real(V(:,j+1));
      j = j+2;
    else B(j,j) = exp(D(j,j)*t);
       P(:,j) = V(:,j);
       j = j+1;
    end
end

x_sol(t) = (P*B/P)*x_0

