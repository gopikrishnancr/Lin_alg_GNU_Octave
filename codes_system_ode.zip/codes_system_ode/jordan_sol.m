clear all;
clc;

A = [1 0 0;-1 2 0;1 1 2];

pkg load symbolic;  
syms t;

% The jordan command in Octave is inside the package symbolic. So, you need to call
% it using the commnad sym(A).
[V, J] = jordan(sym(A));   

D = diag(diag(J));
N = J - D;
k = size(A, 1);

%k=3; % reapting number of the eigen value
Ni=eye(k,k);
for i=1:k
    Ni = Ni+ (t^i* N^(i))/factorial(i);
end

soln = V*diag(exp(diag(J)*t))*Ni/V;

x_0 = [1 0 0];

x_sol = soln*x_0'


