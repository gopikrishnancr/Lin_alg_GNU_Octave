% Coefficient matrices for the problems Q.(1):(a)--(e) %

Ma = [2 1;1 3];
Mb = [0 1;-1 0];
Mc = [2 0 0;0 2 3;0 -3 2];
Md = [2 0 3;0 1 0;1 0 2];
Me = [1 -1 0 0;1 1 0 0;0 0 3 -2;0 0 1 1];